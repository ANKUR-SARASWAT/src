import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';

import { ExpertAuthService } from './expert-auth.service';

@Injectable()
export class AuthGuard implements CanActivate {
    
    constructor(private expertauthservice: ExpertAuthService, private router: Router) {}

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
        // throw new Error("Method Not Implemented.");
        const isAuth = this.expertauthservice.getIsAuth();
        if(!isAuth) {
            this.router.navigate(['/login']);
        }
        return isAuth;
    }
}