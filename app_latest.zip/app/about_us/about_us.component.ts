import { Component } from '@angular/core';

@Component({
  selector: 'my-app-about-us',
  templateUrl: './about_us.component.html',
  styleUrls: [ './about_us.component.css' ]
})
export class AboutUsComponent  {
  
}