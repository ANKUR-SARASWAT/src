import { Component } from '@angular/core';

import { ExpertAuthService } from 'src/app/auth/experts/expert-auth.service';

interface Domains {
    value: string;
    viewValue: string;
}

interface Years {
    value: string;
    viewValue: string;
}

@Component({
    selector: 'my-app-our-experts-dashboard',
    templateUrl: './our_experts-dashboard.component.html',
    styleUrls: [ './our_experts-dashboard.component.css' ]
})
export class OurExpertsDashboardComponent {

    domains: Domains[] = [
        { value: 'hr-0', viewValue: 'HR' },
        { value: 'legal-1', viewValue: 'Legal' },
        { value: 'marketing-2', viewValue: 'Marketing' },
        { value: 'others-3', viewValue: 'Others' }
    ];

    years: Years[] = [
        { value: 'Zero-0', viewValue: '0' },
        { value: 'One-1', viewValue: '1' },
        { value: 'Two-2', viewValue: '2' },
        { value: 'Three-3', viewValue: '3' },
        { value: 'Four-4', viewValue: '4' },
        { value: 'Five-5', viewValue: '5' },
        { value: '5To10-6', viewValue: 'More than 5 and less than 10' },
        { value: '10To15-7', viewValue: 'More than 10 and less than 15' },
        { value: '15To20-8', viewValue: 'More than 15 and less than 20' },
        { value: '20To25-9', viewValue: 'More than 20 and less than 25' },
        { value: '25To30-10', viewValue: 'More than 25 and less than 30' },
        { value: '30To35-11', viewValue: 'More than 30 and less than 35' },
        { value: '35To40-12', viewValue: 'More than 35 and less than 40' },
        { value: '40To45-13', viewValue: 'More than 40 and less than 45' },
        { value: '45To50-14', viewValue: 'More than 45 and less than 50' },
        { value: '50To55-15', viewValue: 'More than 50 and less than 55' },
        { value: '55To60-16', viewValue: 'More than 55 and less than 60' },
        { value: '60-17', viewValue: 'More than 60' }
    ];

    constructor(public expertAuthService: ExpertAuthService) {}

}