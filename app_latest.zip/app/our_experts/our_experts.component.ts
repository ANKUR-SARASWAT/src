import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

import { Experts } from './experts.model';
import { OurExpertsDashboardComponent } from './our_experts-dashboard/our_experts-dashboard.component';

import { ExpertAuthService } from '../auth/experts/expert-auth.service';

@Component({
  selector: 'my-app-our-experts',
  templateUrl: './our_experts.component.html',
  styleUrls: [ './our_experts.component.css' ]
})
export class OurExpertsComponent implements OnInit, OnDestroy {
  
  constructor(public expertAuthService: ExpertAuthService) {}
  
  userIsAuthenticated = false;
  isLoading = false;
  private authListenerSubs: Subscription;

  ngOnInit() {
      this.userIsAuthenticated = this.expertAuthService.getIsAuth();
      this.authListenerSubs = this.expertAuthService.getAuthStatusListener()
          .subscribe(isAuthenticated => {
              this.userIsAuthenticated = isAuthenticated;
          });
  }

  onSignup(form: NgForm) {
    console.log(form.value);
    if(form.invalid) {
        return;
    }
    this.isLoading = true;
    this.expertAuthService.createExpert(form.value.email, form.value.password);
  }

  onLogin(form: NgForm) {
    console.log(form.value);
    if(form.invalid) {
        return;
    }
    this.isLoading = true;
    this.expertAuthService.loginExpert(form.value.email, form.value.password);
  }

  onLogout() {
      this.expertAuthService.logout();
  }

  ngOnDestroy() {
      this.authListenerSubs.unsubscribe();
  }

  // onSignup(form: NgForm){
  //   // console.log(form.value);
  //   if (form.invalid) {
  //     return;
  //   }
  //   this.ExpertAuthService.createExpert(form.value.name, form.value.email, form.value.password);
  // }

  // onLogin(form: NgForm){
  //   console.log(form.value);
  // }

}