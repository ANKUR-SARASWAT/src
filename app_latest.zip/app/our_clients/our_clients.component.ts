import { Component } from '@angular/core';

@Component({
  selector: 'my-app-our-clients',
  templateUrl: './our_clients.component.html',
  styleUrls: [ './our_clients.component.css' ]
})
export class OurClientsComponent  {
  
}