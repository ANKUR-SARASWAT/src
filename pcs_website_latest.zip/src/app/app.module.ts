import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatExpansionModule } from '@angular/material/expansion';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about_us/about_us.component';
import { ContactUsComponent } from './contact_us/contact_us.component';
import { ServicesComponent } from './services/services.component';
import { OurClientsComponent } from './our_clients/our_clients.component';
import { OurExpertsComponent } from './our_experts/our_experts.component';

import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './auth/experts/login/login.component';
import { RegisterComponent } from './auth/experts/register/register.component';
import { ExpertAuthInterceptor } from './auth/experts/expert-auth-interceptor';

@NgModule({
  declarations: [ AppComponent, HeaderComponent, FooterComponent, HomeComponent, AboutUsComponent,
                  ContactUsComponent, ServicesComponent, OurClientsComponent, OurExpertsComponent,
                  LoginComponent, RegisterComponent ],
  imports:      [ BrowserModule, FormsModule, AppRoutingModule, BrowserAnimationsModule, HttpClientModule,
                  MatInputModule, MatCardModule, MatButtonModule, MatToolbarModule, MatExpansionModule ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: ExpertAuthInterceptor, multi: true }],                
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
