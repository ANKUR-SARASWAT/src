import { Component } from '@angular/core';

@Component({
  selector: 'my-app-contact-us',
  templateUrl: './contact_us.component.html',
  styleUrls: [ './contact_us.component.css' ]
})
export class ContactUsComponent  {
  
}