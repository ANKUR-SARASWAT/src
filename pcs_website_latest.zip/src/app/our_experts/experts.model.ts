export interface Experts {
    id: string;
    // userID: string;
    // userName: string;
    emailID: string;
    password: string;
    // userActive: string;
}