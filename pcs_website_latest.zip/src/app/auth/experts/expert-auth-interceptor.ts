import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
import { Injectable } from '@angular/core';

import { ExpertAuthService } from './expert-auth.service';

@Injectable()
export class ExpertAuthInterceptor implements HttpInterceptor {
    
    constructor(private expertauthservice: ExpertAuthService) {}
    
    intercept(req: HttpRequest<any>, next: HttpHandler) {
        const expertAuthToken = this.expertauthservice.getToken();
        const expertAuthRequest = req.clone({
            headers: req.headers.set("Authorization", "Bearer " + expertAuthToken)
        });
        return next.handle(req);
    }
}