const mongoose = require('mongoose');
const uniqueValidator = require("mongoose-unique-validator") ;

const expertsSchema = mongoose.Schema({
    // userID: { type: String, required: true },
    // userName: { type: String, required: true },
    email: { type: String, required: true , unique: true },
    password: { type: String, required: true }
    // userActive: { type: String, required: true },
});

expertsSchema.plugin(uniqueValidator);

module.exports = mongoose.model('Experts', expertsSchema);