import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about_us/about_us.component';
import { ContactUsComponent } from './contact_us/contact_us.component';
import { ServicesComponent } from './services/services.component';
import { OurClientsComponent } from './our_clients/our_clients.component';
import { OurExpertsComponent } from './our_experts/our_experts.component';

import { APP_BASE_HREF } from '@angular/common';

const appRoutes: Routes = [
    // { path: '', component: HomeComponent },
    // { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'about-us', component: AboutUsComponent },
    { path: 'contact-us', component: ContactUsComponent },
    { path: 'services', component: ServicesComponent },
    { path: 'our-clients', component: OurClientsComponent },
    { path: 'our-experts', component: OurExpertsComponent },
    { path: '**', redirectTo: '/home' } //'/not-found' }
];

@NgModule({
    imports: [RouterModule.forRoot(appRoutes)],
    exports: [RouterModule],
    providers: [{provide: APP_BASE_HREF, useValue : '/' }]
})
export class AppRoutingModule{

}