import { Component } from '@angular/core';

@Component({
  selector: 'my-app-our-experts',
  templateUrl: './our_experts.component.html',
  styleUrls: [ './our_experts.component.css' ]
})
export class OurExpertsComponent  {
  
}