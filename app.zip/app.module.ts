import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { AboutUsComponent } from './about_us/about_us.component';
import { ContactUsComponent } from './contact_us/contact_us.component';
import { ServicesComponent } from './services/services.component';
import { OurClientsComponent } from './our_clients/our_clients.component';
import { OurExpertsComponent } from './our_experts/our_experts.component';

import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [ AppComponent, HeaderComponent, FooterComponent, HomeComponent, AboutUsComponent,
                  ContactUsComponent, ServicesComponent, OurClientsComponent, OurExpertsComponent ],
  imports:      [ BrowserModule, FormsModule, AppRoutingModule, BrowserAnimationsModule ],
  bootstrap:    [ AppComponent ]
})

export class AppModule { }
